result.Entity = require('./entity');
result.Dog = require('./dog');
result.Person = require('./person');
result.Student = require('./student');